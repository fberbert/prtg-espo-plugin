<?php

namespace Espo\Modules\PrtgIntegration\Controllers;

use Espo\Core\Controllers\Record;

class Prtg extends Record
{
}
